#pragma once
#include <stdint.h>

void cicuta_virosa(void);
