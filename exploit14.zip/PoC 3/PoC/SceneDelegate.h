//
//  ViewController.m
//  Exploit14
//
//  Created by Hoa Huynh on 1/12/20.
//  Copyright © 2020 LiRa Team. All rights reserved.

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

