//
//  ViewController.m
//  Exploit14
//
//  Created by Hoa Huynh on 1/12/20.
//  Copyright © 2020 LiRa Team. All rights reserved.

#import "ViewController.h"
#import <sys/sysctl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <mach/mach.h>
#include "platform.h"
#include "checkinfo.h"
#include "common.h"
#include "cicuta_virosa.h"


@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIButton *button;
@property (weak, nonatomic) IBOutlet UITextView *logview;
@end

@implementation ViewController

#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)     ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)
#define printf(X,X1...) {char logdata[256];snprintf(logdata, sizeof(logdata), X, X1);extern void log_toView(const char *input_cstr);log_toView(logdata);}
#define printf2(X) {extern void log_toView(const char *input_cstr);log_toView(X);}


vm_size_t get_kernel_page_size() {
    vm_size_t kernel_page_size = 0;
    vm_size_t *out_page_size = NULL;
    host_t host = mach_host_self();
    if (!MACH_PORT_VALID(host)) goto out;
    out_page_size = (vm_size_t *)malloc(sizeof(vm_size_t));
    if (out_page_size == NULL) goto out;
    bzero(out_page_size, sizeof(vm_size_t));
    if (_host_page_size(host, out_page_size) != KERN_SUCCESS) goto out;
    kernel_page_size = *out_page_size;
out:
    if (MACH_PORT_VALID(host)) mach_port_deallocate(mach_task_self(), host); host = HOST_NULL;
    SafeFreeNULL(out_page_size);
    return kernel_page_size;
}

char *getKernelVersion() {
    return sysctlWithName("kern.version");
}

char *sysctlWithName(const char *name) {
    kern_return_t kr = KERN_FAILURE;
    char *ret = NULL;
    size_t *size = NULL;
    size = (size_t *)malloc(sizeof(size_t));
    if (size == NULL) goto out;
    bzero(size, sizeof(size_t));
    if (sysctlbyname(name, NULL, size, NULL, 0) != ERR_SUCCESS) goto out;
    ret = (char *)malloc(*size);
    if (ret == NULL) goto out;
    bzero(ret, *size);
    if (sysctlbyname(name, ret, size, NULL, 0) != ERR_SUCCESS) goto out;
    kr = KERN_SUCCESS;
out:
    if (kr == KERN_FAILURE) SafeFreeNULL(ret);
    SafeFreeNULL(size);
    return ret;
}

UITextView *log_outview_toC;
void log_toView(const char *input_cstr){
    
    dispatch_sync( dispatch_get_main_queue(), ^{
        log_outview_toC.text = [log_outview_toC.text stringByAppendingString:[NSString stringWithUTF8String:input_cstr]];
        [log_outview_toC scrollRangeToVisible:NSMakeRange(log_outview_toC.text.length, 1)];
    });
    
}

void run() {
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"14.3")){

        extern char *get_deviceModel(void);
        printf("Thiết bị: %s  (%s)\n", get_current_deviceModel(), platform.machine);
           printf("Phiên Bản: %s ", [[[UIDevice currentDevice] systemVersion] UTF8String]);
        printf("(%s)\n",platform.osversion);
        printf2("Phiên bản iOS không hộ trợ\n");
    }
    if (SYSTEM_VERSION_LESS_THAN(@"14.3")){
    extern char *get_current_deviceModel(void);
    printf("Thiết bị: %s  (%s)\n", get_current_deviceModel(), platform.machine);
       printf("Phiên Bản: %s ", [[[UIDevice currentDevice] systemVersion] UTF8String]);
        printf("(%s)\n",platform.osversion);
        printf("Kernel Page Size: 0x%lx\n", get_kernel_page_size());
            char *kernelVersion = NULL;
            kernelVersion = getKernelVersion();
            if (kernelVersion == NULL) goto out;
             printf("Kernel Version: %s\n", kernelVersion)
        out:
            SafeFreeNULL(kernelVersion);
        sleep (1);
    printf2("Exploiting...\n");
        sleep (1);
        extern void cicuta_virosa(void);
        cicuta_virosa();
        return;
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Background UI config
    log_outview_toC = self.logview;
}
- (IBAction)onStartPressed:(UIButton *)sender {
     dispatch_async(dispatch_get_main_queue(), ^{
         dispatch_async(dispatch_queue_create("exploit_main_loop", 0), ^{
            run();
         });
     });
 }

@end
