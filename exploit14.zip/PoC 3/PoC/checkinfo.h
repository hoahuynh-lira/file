//
//  PoC.h
//  Taifu
//
//  Created by hoahuynh on 12/12/20.
//  Copyright © 2020 Hoà Huỳnh. All rights reserved.
//
#import <UIKit/UIKit.h>

char *get_current_deviceModel();
